#import library's
import time
import math
import IMU
import datetime
import os
import sys

G_GAIN = 0.070

#variable to check moving
moving = False

#variable to check if ball hit a person
missed = True
hit = False
catched = False

IMU.detectIMU()     #Detect IMU
IMU.initIMU()       #Initialise the accelerometer, gyroscope and compass
print "Application starts"

#algorithm to calculate velocity
def calcVel(valueX, valueY, valueZ):
	xComb = valueX * valueX
	yComb = valueY * valueY
	zComb = valueZ * valueZ
	xyComb = xComb + yComb
	v1 = math.sqrt(xyComb)
	zv1Comb = zComb + v1
	v2 = math.sqrt(zv1Comb)
	print v2
	return v2

#algorithm to calculate the two highest value
def maximum(valueX, valueY, valueZ):
	#declare variables
	x = "x"
	y = "y"
	z = "z"

	#check which two variables are the highest
	if valueX > valueY and valueX > valueZ:
		if valueY > valueZ:
			return x, y
		else:
			return x, z

	if valueY > valueX and valueY > valueZ:
		if valueX > valueZ:
			return x, y
		else:
			return y, z

	if valueZ > valueX and valueZ > valueY:
		if valueX > valueY:
			return x, z
		else:
			return y, z

#loop
while True:
	time.sleep(1)

	#try: catch exceptions
	try:


		#Read the accelerometer values
    		def readAcc():
			ACCx = IMU.readACCx()
    			ACCy = IMU.readACCy()
    			ACCz = IMU.readACCz()
		
			x = (ACCx * 0.700) / 1000
			y = (ACCy * 0.700) / 1000
			z = (ACCz * 0.700) / 1000
			return x, y, z

		
		#Read the gyroscope values
		def readGyr():
			#save raw values
    			GYRx = IMU.readGYRx()
    			GYRy = IMU.readGYRy()
    			GYRz = IMU.readGYRz()

			#set to degrees per second + to the square
			rate_gyr_x = math.sqrt((GYRx * G_GAIN) ** 2)
			rate_gyr_y = math.sqrt((GYRy * G_GAIN) ** 2)
			rate_gyr_z = math.sqrt((GYRz * G_GAIN) ** 2)
			return rate_gyr_x, rate_gyr_y, rate_gyr_z

		#Get highest accelleration of gyroscope
		gyX, gyY, gyZ = readGyr()
		val1, val2 = maximum(gyX, gyY, gyZ)

		#save accellero values in variables
		x, y, z = readAcc()

		#calculate velocity
    		velc = calcVel(x, y, z)	

		#function: ball hits an object
		def stopMovement():
			global moving
			global missed
			global catched
			global hit

			#set timer
			t = time.time() + 2

			#while lus: till time runs out
			while time.time() < t:

				#check if ball is moving
				if moving == True:
					#re-ask values of accellero
					x, y, z = readAcc()

					#re-calculate velocity
					velc = calcVel(x, y, z)

					#re-ask values of gyro
					gX, gY, gZ = readGyr()

					#check if ball hit anything
					if velc < 0.7:
						#ball hit an object
						moving = False

						#start timer
						t = time.time() + 1

						#while lus: check if person catched the ball
						while time.time() < t:

							#recalculate values
							x, y, z = readAcc()

							#recalculate velocity
							velc = calcVel(x, y, z)

							#re-ask values of gyro
							gX, gY, gZ = readGyr()

							#check degrees of gyro
							val3, val4 = maximum(gX, gY, gZ)


							#only check values once
							if missed == True:
								#if-structure check if gyro values are different
								if val1 != val3 and val2 != val4:
									missed = False
							
								else:
									missed = True

							
							#if structure: check if person catched the ball
							if velc > 2:
							
								#check if person was hit or the floor
								if missed == True:
									hit = False
									exit()
		
								else:
									hit = True
									exit()
								

							else:
								catched = True

							
						#FINAL CHECK: which action has occurred
						if hit == True:
							print "HIT PERSON"
							catched = False
							time.sleep(5)

						elif hit == False:
							print "HIT FLOOR"
							catched = False
							time.sleep(5)

						if catched == True:
							print "CATCHED"
							time.sleep(5)

						#set all variables back to false
						catched = False
						hit = False
						missed = True

				else:
					#exit code or will give runtime errors
					#don't forget to reset hit
					moving = False
					exit()

		#functions: to check movement
		def bigMovement():
			#in every function you need to call the global varialbe
			global moving

			#function: see if ball is thrown
			moving = True

			#call stop movement function
			stopMovement() 

		def smallMovement():
			global moving
			moving = False

		def noMovement():
			global moving
			moving = False

		#if structure: control if ball is moving or not
		if velc > 6:
			bigMovement()
		elif velc > 3:
			smallMovement()
		else:
			noMovement()



	#exceptions
	#ctrl + c interrupt
	except KeyboardInterrupt:
		#shut down code
		exit()
