#import library's
import time
import math
import IMU
import datetime
import os
import sys
import paho.mqtt.client as mqtt

#settings for MQTT
topic = "testtopic"

#connect via mqtt
def on_connect(client, userdata, flags, rc):
	print("Connected with result code " + str(rc))
	client.subscribe(topic)
	client.publish("testtopic", "Start publishing")

#send messages via mqtt
def on_message(msg):
	client.publish("testtopic", msg, retain=True)


#connect to client
client = mqtt.Client()
client.connect("192.168.1.200", 1883, 60)

#connect for mqtt
client.on_connect = on_connect



#variable used to calculate degrees/s of  gyro
G_GAIN = 0.070

#variable to check moving
moving = False

#variables to check if ball hit a person
missed = True
hit = False
catched = False

IMU.detectIMU()     #Detect IMU
IMU.initIMU()       #Initialise the accelerometer, gyroscope and compass
print "Application starts"

#algorithm to calculate velocity
def calcVel(valueX, valueY, valueZ):
	xComb = valueX * valueX
	yComb = valueY * valueY
	zComb = valueZ * valueZ
	xyComb = xComb + yComb
	v1 = math.sqrt(xyComb)
	zv1Comb = zComb + v1
	v2 = math.sqrt(zv1Comb)
	return v2

#algorithm to calculate the two highest value
def maximum(valueX, valueY, valueZ):
	#declare variables
	x = "x"
	y = "y"
	z = "z"

	#check which two variables are the highest
	if valueX >= valueY and valueX >= valueZ:
		if valueY >= valueZ:
			return x, y
		else:
			return x, z

	if valueY >= valueX and valueY >= valueZ:
		if valueX >= valueZ:
			return x, y
		else:
			return y, z

	if valueZ >= valueX and valueZ >= valueY:
		if valueX >= valueY:
			return x, z
		else:
			return y, z


#declare variables to save gyroscope values
val1 = 0.0
val2 = 0.0
val3 = 0.0
val4 = 0.0



index = 0 

#loop
while True:
	
	#try: catch exceptions
	try:


		#TEST MQTT CODE
		while index < 1:
			client.loop_start()
			client.loop_stop()


		#Read the accelerometer values
    		def readAcc():
			ACCx = IMU.readACCx()
    			ACCy = IMU.readACCy()
    			ACCz = IMU.readACCz()
		
			x = (ACCx * 0.700) / 1000
			y = (ACCy * 0.700) / 1000
			z = (ACCz * 0.700) / 1000
			return x, y, z

		
		#Read the gyroscope values
		def readGyr():
			#save raw values
    			GYRx = IMU.readGYRx()
    			GYRy = IMU.readGYRy()
    			GYRz = IMU.readGYRz()

			#set to degrees per second + to the square
			rate_gyr_x = math.sqrt((GYRx * G_GAIN) ** 2)
			rate_gyr_y = math.sqrt((GYRy * G_GAIN) ** 2)
			rate_gyr_z = math.sqrt((GYRz * G_GAIN) ** 2)
			return rate_gyr_x, rate_gyr_y, rate_gyr_z

		#Get highest accelleration of gyroscope
		gyX, gyY, gyZ = readGyr()


		#if values are null -> change values
		if gyX == 0:
			gyX = 0.0001
		if gyY == 0:
			gyY = 0.0001
		if gyZ == 0:
			gyZ = 0.0001


		#get two highest values
		val1, val2 = maximum(gyX, gyY, gyZ)


		#save accellero values in variables
		x, y, z = readAcc()

		#calculate velocity
    		velc = calcVel(x, y, z)	

		#function: ball hits an object
		def stopMovement():
			#call globals variables
			global moving
			global missed
			global catched
			global hit

			#set timer for 2 seconds
			t = time.time() + 2

			#while lus: till time runs out
			while time.time() < t:

				#check if ball is moving
				if moving == True:
					#re-ask values of accellero
					x, y, z = readAcc()

					#re-calculate velocity
					velc = calcVel(x, y, z)

					#re-ask values of gyro
					gX, gY, gZ = readGyr()

					#check if ball hit anything
					if velc < 0.7:
						#ball hit an object
						moving = False

						#start timer
						t = time.time() + 1

						#while lus: check if person catched the ball
						while time.time() < t:

							#recalculate values
							x, y, z = readAcc()

							#recalculate velocity
							velc = calcVel(x, y, z)

							#re-ask values of gyro
							gX, gY, gZ = readGyr()

							#check degrees of gyro
							val3, val4 = maximum(gX, gY, gZ)


							#only check values once
							if missed == True:
								#if-structure check if gyro values are different
								if val1 != val3 and val2 != val4:
									#person hit
									missed = False
							
								else:
									#floor hit
									missed = True

							
							#if structure: check if person catched the ball
							if velc > 2:
							
								#check if person was hit or the floor
								if missed == True:
									hit = False
									exit()
		
								else:
									hit = True
									exit()
								

							else:
								catched = True

							
						#FINAL CHECK: which action has occurred
						if hit == True:
				
							#loop mqtt
						        client.loop_start()
							
							#send hit message once!
							i = 0
							while i < 1:
        							client.on_message = on_message("hit")
        						i += 1

				
     							#stop mqtt
        						client.loop_stop()

							#indication in code that person was hit
							print "HIT PERSON"
							catched = False

						elif hit == False:
							# HIT FLOOR
							catched = False
							

						if catched == True:
							# CATCHED
							catched = True

						#set all variables back to false
						catched = False
						hit = False
						missed = True

				else:
					#exit code or will give runtime errors
					#don't forget to reset hit
					moving = False
					exit()

		#functions: to check movement
		def bigMovement():
			#in every function you need to call the global varialbe
			global moving

			#function: see if ball is thrown
			moving = True

			#call stop movement function
			stopMovement() 

		def smallMovement():
			#call global variable
			global moving

			#set variable back to false
			moving = False

		def noMovement():
			#call global variable
			global moving

			#set variable back to false
			moving = False

		#if structure: control if ball is moving or not
		if velc > 6:
			bigMovement()
		elif velc > 3:
			smallMovement()
		else:
			noMovement()



	#exceptions
	#ctrl + c interrupt
	except KeyboardInterrupt:
		#shutdown mqtt connection
		client.loop_stop()
		
		#shut down code
		exit()
		
