#TEST SCRIPT TO CHECK FOR DEGREES

import time
import math
import IMU
import datetime
import os
import sys

RAD_TO_DEG = 57.29578
M_PI = 3.141592
G_GAIN = 0.070
AA = 0.40

gyroXangle = 0.0
gyroYangle = 0.0
gyroZangle = 0.0
CFangleX = 0.0
CFangleY = 0.0

IMU.detectIMU()
IMU.initIMU()
print("application starts")

index = 0
while index < 1:
	time.sleep(0.1)

	GYRx = IMU.readGYRx()
	GYRy = IMU.readGYRy()
	GYRz = IMU.readGYRz()

	x = math.sqrt((GYRx * G_GAIN) ** 2)
	y = math.sqrt((GYRy * G_GAIN) ** 2)
	z = math.sqrt((GYRz * G_GAIN) ** 2)

#	if x > y and x > z:
#		print(" x = %F" % x)
#	if y > x and y > z:
#		print(" y = %F" % y)
#	if z > x and z > y:
#		print(" z = %F" % z)
	print("Code finished")

	index = 1
	
