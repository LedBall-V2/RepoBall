# importing library's
import adxl345
import time
import sys

# Create new object
acc = adxl345.ADXl345()
acc.setRange(adxl345.RANGE_2G)

# loop
while True:
    # get data from acc
    axes = acc.getAxes(True)

    # save values
    x = axes['x']
    y = axes['y']
    z = axes['z']

    # print values
    print(x)
    print(y)
    print(z)

    # delay
    time.sleep(2)
