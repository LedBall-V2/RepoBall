# importing library's
import adxl345
import time

# Create new object
acc = adxl345.ADXl345()
acc.setRange(adxl345.RANGE_2G)


# Define function to convert raw analog values to gravities.
def accel_value(axis):
    # Convert axis value to float within 0...1 range.
    val = axis.value / 65535
    # Shift values to true center (0.5).
    val -= 0.5
    # Convert to gravities.
    return val * 3.0


# loop
while True:
    # get data from acc
    axes = acc.getAxes(True)

    # save values
    xValue = axes['x']
    yValue = axes['y']
    zValue = axes['z']
    x = accel_value(xValue)
    y = accel_value(yValue)
    z = accel_value(zValue)
    print('Acceleration (G): ({0}, {1}, {2})'.format(x, y, z))

    # delay
    time.sleep(1.0)