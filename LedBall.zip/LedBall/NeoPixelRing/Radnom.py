import time
from neopixel import *

LEDS = 32
PIN = 18
BRIGHTNESS = 25

KLEUR_R = 255
KLEUR_G = 255
KLEUR_B = 255

def loopLed(ring, color):
        for i in range(ring.numPixels()):
                ring.setPixelColor(i, color)
                ring.show()


def resetLeds(ring, color, count):
        for i in range(ring.numPixels() - count):
                ring.setPixelColor(i, color)
                ring.show()

if __name__ == '__main__':
        ring = Adafruit_NeoPixel(LEDS, PIN, 800000, 10, False, BRIGHTNESS)
        ring.begin()

        def full():
                loopLed(ring, Color(KLEUR_B, KLEUR_G, KLEUR_R))
                time.sleep(3)

        def onehit():
                resetLeds(ring, Color(0, 0, 0), 24)
                time.sleep(3)

        def twohit():
                resetLeds(ring, Color(0, 0, 0), 16)
                time.sleep(3)

        def thirdhit():
                resetLeds(ring, Color(0, 0, 0), 8)
                time.sleep(3)

        def dead():
                resetLeds(ring, Color(0, 0, 0), 0)
                time.sleep(0.5)
                for i in range(0, 3, 1):
                        loopLed(ring, Color(KLEUR_B, KLEUR_G, KLEUR_R))
                        time.sleep(0.2)
                        resetLeds(ring, Color(0, 0, 0), 0)
                        time.sleep(0.2)

        full()
        lives = int(input("Geef ke een waarde in nichtbak: "))

        while True:
                if lives == 0:
                        full()
                        lives = int(input("Geef ke een waarde in nichtbak: "))
                elif lives == 1:
                        onehit()
                        lives = int(input("Geef ke een waarde in nichtbak: "))
                elif lives == 2:
                        twohit()
                        lives = int(input("Geef ke een waarde in nichtbak: "))
                elif lives == 3:
                        thirdhit()
                        lives = int(input("Geef ke een waarde in nichtbak: "))
                else:
                        dead()
                        exit()

