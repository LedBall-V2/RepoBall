import time
from neopixel import *

LEDS = 32
PIN = 18
BRIGHTNESS = 5

KLEUR_R = 0
KLEUR_G = 255
KLEUR_B = 0

ring = Adafruit_NeoPixel(LEDS, PIN, brightness=1)
ring.begin()


def loopLed(ring, color):
        for i in range(ring.numPixels()):
                ring.setPixelColor(i, color)
                ring.show()

def resetLeds(ring, color):
        for i in range(ring.numPixels()):
                ring.setPixelColor(i, color)
                ring.show()

for i in range(0, 1, 1):
        loopLed(ring, Color(0, 255, 0))
        time.sleep(10)


resetLeds(ring, Color(0, 0, 0))
